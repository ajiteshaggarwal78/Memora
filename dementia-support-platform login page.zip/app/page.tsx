import { AuthForm } from '@/components/auth/auth-form'
import { InfoPanel } from '@/components/auth/info-panel'

export default function Page() {
  return (
    <main className="grid min-h-screen lg:grid-cols-[1.1fr_1fr]">
      <InfoPanel />
      <div className="flex items-center justify-center p-6 sm:p-10">
        <AuthForm />
      </div>
    </main>
  )
}
